import { Step } from '../types/Subject';

export const generateStepByStepSolution = (question: string, subject: string): { steps: Step[], keyPoints: string[] } => {
  const lowerQuestion = question.toLowerCase();
  
  // Mathematics Solutions
  if (subject === 'mathematics') {
    // Multiplication tables
    if (lowerQuestion.includes('times table') || (lowerQuestion.includes('times') && /\d+/.test(lowerQuestion))) {
      const number = lowerQuestion.match(/(\d+)/)?.[1] || '8';
      return {
        steps: [
          {
            number: 1,
            title: `Understanding the ${number} times table`,
            content: `The ${number} times table shows what happens when we multiply ${number} by different numbers.`,
            example: `${number} × 1, ${number} × 2, ${number} × 3, and so on...`
          },
          {
            number: 2,
            title: "The complete table",
            content: `Here's the full ${number} times table from 1 to 12:`,
            formula: Array.from({length: 12}, (_, i) => `${number} × ${i + 1} = ${parseInt(number) * (i + 1)}`).join('\n')
          },
          {
            number: 3,
            title: "Pattern recognition",
            content: `Look for patterns in the ${number} times table to help memorize it.`,
            example: parseInt(number) % 2 === 0 ? "All answers are even numbers" : "The answers alternate between odd and even"
          },
          {
            number: 4,
            title: "Practice tips",
            content: "Use these strategies to memorize the times table effectively.",
            example: `Skip counting: ${number}, ${parseInt(number) * 2}, ${parseInt(number) * 3}, ${parseInt(number) * 4}...`
          }
        ],
        keyPoints: [
          `Multiplication is repeated addition: ${number} × 3 means ${number} + ${number} + ${number}`,
          "Look for patterns to make memorization easier",
          "Practice regularly with flashcards or games",
          "Once you know the pattern, you can figure out any multiplication"
        ]
      };
    }

    // Basic arithmetic operations
    if (lowerQuestion.includes('add') || lowerQuestion.includes('addition') || lowerQuestion.includes('+')) {
      const numbers = lowerQuestion.match(/\d+/g);
      if (numbers && numbers.length >= 2) {
        const num1 = parseInt(numbers[0]);
        const num2 = parseInt(numbers[1]);
        const result = num1 + num2;
        
        return {
          steps: [
            {
              number: 1,
              title: "Identify the numbers to add",
              content: "Write down the numbers we need to add together.",
              formula: `${num1} + ${num2}`
            },
            {
              number: 2,
              title: "Line up the numbers",
              content: "For larger numbers, line them up by place value (ones, tens, hundreds).",
              formula: `  ${num1}\n+ ${num2}\n----`
            },
            {
              number: 3,
              title: "Add from right to left",
              content: "Start with the ones place and work your way left.",
              calculation: `${num1} + ${num2} = ${result}`
            },
            {
              number: 4,
              title: "Check your answer",
              content: "Verify by adding in reverse order or using estimation.",
              example: `${num2} + ${num1} = ${result} ✓`
            }
          ],
          keyPoints: [
            "Always line up numbers by place value",
            "Start adding from the rightmost column (ones place)",
            "Carry over when a column sum is 10 or more",
            "Check your work by adding in reverse order"
          ]
        };
      }
    }

    // Subtraction
    if (lowerQuestion.includes('subtract') || lowerQuestion.includes('subtraction') || lowerQuestion.includes('-')) {
      const numbers = lowerQuestion.match(/\d+/g);
      if (numbers && numbers.length >= 2) {
        const num1 = parseInt(numbers[0]);
        const num2 = parseInt(numbers[1]);
        const result = num1 - num2;
        
        return {
          steps: [
            {
              number: 1,
              title: "Set up the subtraction",
              content: "Write the larger number on top and the smaller number below it.",
              formula: `  ${num1}\n- ${num2}\n----`
            },
            {
              number: 2,
              title: "Subtract from right to left",
              content: "Start with the ones place and work your way left.",
              example: "If the top digit is smaller, you'll need to borrow from the next column"
            },
            {
              number: 3,
              title: "Calculate the result",
              content: "Perform the subtraction in each column.",
              calculation: `${num1} - ${num2} = ${result}`
            },
            {
              number: 4,
              title: "Verify your answer",
              content: "Check by adding your answer to the number you subtracted.",
              example: `${result} + ${num2} = ${num1} ✓`
            }
          ],
          keyPoints: [
            "Always subtract the smaller number from the larger number",
            "Borrow from the next column when needed",
            "Work from right to left (ones, tens, hundreds)",
            "Check by adding your answer to the subtracted number"
          ]
        };
      }
    }

    // Existing solutions...
    if (lowerQuestion.includes('solve') && lowerQuestion.includes('x') && lowerQuestion.includes('=')) {
      return {
        steps: [
          {
            number: 1,
            title: "Write down the equation",
            content: "Start by clearly writing the equation we need to solve.",
            formula: "2x + 5 = 17"
          },
          {
            number: 2,
            title: "Subtract 5 from both sides",
            content: "To isolate the term with x, we subtract 5 from both sides of the equation.",
            formula: "2x + 5 - 5 = 17 - 5",
            calculation: "2x = 12"
          },
          {
            number: 3,
            title: "Divide both sides by 2",
            content: "Now divide both sides by 2 to solve for x.",
            formula: "2x ÷ 2 = 12 ÷ 2",
            calculation: "x = 6"
          },
          {
            number: 4,
            title: "Check your answer",
            content: "Substitute x = 6 back into the original equation to verify.",
            formula: "2(6) + 5 = 17",
            calculation: "12 + 5 = 17 ✓"
          }
        ],
        keyPoints: [
          "Always perform the same operation on both sides of the equation",
          "Work systematically to isolate the variable",
          "Check your answer by substituting back into the original equation",
          "Keep your work organized and show each step clearly"
        ]
      };
    }
    
    if (lowerQuestion.includes('area') && lowerQuestion.includes('circle')) {
      return {
        steps: [
          {
            number: 1,
            title: "Identify the given information",
            content: "Write down what we know about the circle.",
            formula: "Radius (r) = 7 cm"
          },
          {
            number: 2,
            title: "Write the area formula",
            content: "The formula for the area of a circle is A = πr².",
            formula: "A = πr²"
          },
          {
            number: 3,
            title: "Substitute the values",
            content: "Replace r with 7 in the formula.",
            formula: "A = π × (7)²",
            calculation: "A = π × 49"
          },
          {
            number: 4,
            title: "Calculate the final answer",
            content: "Multiply to get the area in terms of π, or use π ≈ 3.14159 for a decimal answer.",
            formula: "A = 49π cm²",
            calculation: "A ≈ 153.94 cm²"
          }
        ],
        keyPoints: [
          "Always identify what information is given in the problem",
          "Remember the area formula: A = πr²",
          "You can leave answers in terms of π or use decimal approximation",
          "Don't forget to include units in your final answer"
        ]
      };
    }

    // Fractions
    if (lowerQuestion.includes('fraction') || lowerQuestion.includes('/')) {
      return {
        steps: [
          {
            number: 1,
            title: "Understanding fractions",
            content: "A fraction represents a part of a whole, written as numerator/denominator.",
            example: "In 3/4, the 3 is the numerator (parts we have) and 4 is the denominator (total parts)"
          },
          {
            number: 2,
            title: "Adding fractions",
            content: "To add fractions, they must have the same denominator (bottom number).",
            formula: "1/4 + 2/4 = 3/4",
            example: "Same denominator: just add the numerators"
          },
          {
            number: 3,
            title: "Different denominators",
            content: "When denominators are different, find a common denominator first.",
            formula: "1/3 + 1/6 = 2/6 + 1/6 = 3/6 = 1/2",
            example: "Convert 1/3 to 2/6 so both fractions have denominator 6"
          },
          {
            number: 4,
            title: "Simplifying fractions",
            content: "Reduce fractions to lowest terms by dividing both parts by their greatest common factor.",
            example: "6/8 = 3/4 (divide both by 2)"
          }
        ],
        keyPoints: [
          "The denominator tells you how many equal parts the whole is divided into",
          "The numerator tells you how many of those parts you have",
          "Always simplify your final answer",
          "Find common denominators when adding or subtracting fractions"
        ]
      };
    }
  }
  
  // Science Solutions
  if (subject === 'science') {
    // Periodic table questions
    if (lowerQuestion.includes('periodic table') || lowerQuestion.includes('element')) {
      return {
        steps: [
          {
            number: 1,
            title: "What is the periodic table?",
            content: "The periodic table organizes all known chemical elements by their atomic number.",
            example: "Elements are arranged in rows (periods) and columns (groups)"
          },
          {
            number: 2,
            title: "Reading element information",
            content: "Each element box contains the symbol, atomic number, and atomic mass.",
            example: "Hydrogen (H): Atomic number 1, atomic mass ~1.008"
          },
          {
            number: 3,
            title: "Groups and periods",
            content: "Elements in the same column (group) have similar properties.",
            example: "Group 1 elements (like sodium and potassium) are all highly reactive metals"
          },
          {
            number: 4,
            title: "Using the periodic table",
            content: "The table helps predict element properties and chemical behavior.",
            example: "Elements on the left are metals, on the right are non-metals"
          }
        ],
        keyPoints: [
          "Atomic number = number of protons in the nucleus",
          "Elements in the same group have similar chemical properties",
          "The table is organized by increasing atomic number",
          "It's one of the most important tools in chemistry"
        ]
      };
    }

    // States of matter
    if (lowerQuestion.includes('states of matter') || lowerQuestion.includes('solid') || lowerQuestion.includes('liquid') || lowerQuestion.includes('gas')) {
      return {
        steps: [
          {
            number: 1,
            title: "The three main states",
            content: "Matter exists in three main states: solid, liquid, and gas.",
            example: "Ice (solid), water (liquid), steam (gas)"
          },
          {
            number: 2,
            title: "Solid state",
            content: "In solids, particles are tightly packed and vibrate in fixed positions.",
            example: "Solids have definite shape and volume"
          },
          {
            number: 3,
            title: "Liquid state",
            content: "In liquids, particles are close but can move around each other.",
            example: "Liquids have definite volume but take the shape of their container"
          },
          {
            number: 4,
            title: "Gas state",
            content: "In gases, particles move freely and are far apart.",
            example: "Gases have no definite shape or volume - they expand to fill their container"
          },
          {
            number: 5,
            title: "Changing states",
            content: "Matter can change states when energy (usually heat) is added or removed.",
            example: "Melting (solid→liquid), boiling (liquid→gas), freezing (liquid→solid)"
          }
        ],
        keyPoints: [
          "Particle movement increases from solid to liquid to gas",
          "Temperature and pressure affect state changes",
          "Energy is required to change from solid to liquid to gas",
          "The same substance can exist in all three states"
        ]
      };
    }

    // Existing solutions...
    if (lowerQuestion.includes('photosynthesis')) {
      return {
        steps: [
          {
            number: 1,
            title: "Define photosynthesis",
            content: "Photosynthesis is the process by which plants convert light energy into chemical energy (glucose).",
            example: "Plants use sunlight to make their own food"
          },
          {
            number: 2,
            title: "Identify the reactants",
            content: "The raw materials needed for photosynthesis are carbon dioxide and water.",
            formula: "6CO₂ + 6H₂O"
          },
          {
            number: 3,
            title: "Add energy source",
            content: "Light energy (usually from the sun) is required to drive the reaction.",
            formula: "6CO₂ + 6H₂O + light energy"
          },
          {
            number: 4,
            title: "Show the products",
            content: "The products are glucose and oxygen.",
            formula: "6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂"
          },
          {
            number: 5,
            title: "Explain the significance",
            content: "This process produces oxygen for us to breathe and glucose for the plant's energy.",
            example: "Without photosynthesis, there would be no oxygen in our atmosphere"
          }
        ],
        keyPoints: [
          "Photosynthesis occurs in the chloroplasts of plant cells",
          "Chlorophyll is the green pigment that captures light energy",
          "This process is essential for all life on Earth",
          "Plants are called producers because they make their own food"
        ]
      };
    }
    
    if (lowerQuestion.includes('force') && lowerQuestion.includes('accelerate')) {
      return {
        steps: [
          {
            number: 1,
            title: "Identify the given information",
            content: "Write down what we know from the problem.",
            formula: "Mass (m) = 10 kg, Acceleration (a) = 5 m/s²"
          },
          {
            number: 2,
            title: "Write Newton's second law",
            content: "The relationship between force, mass, and acceleration is given by Newton's second law.",
            formula: "F = ma"
          },
          {
            number: 3,
            title: "Substitute the values",
            content: "Replace m and a with the given values.",
            formula: "F = 10 kg × 5 m/s²"
          },
          {
            number: 4,
            title: "Calculate the force",
            content: "Multiply to find the force in Newtons.",
            calculation: "F = 50 N"
          }
        ],
        keyPoints: [
          "Force is measured in Newtons (N)",
          "Newton's second law: F = ma",
          "More mass or more acceleration requires more force",
          "This law explains why it's harder to push a heavy object"
        ]
      };
    }
  }
  
  // English Solutions
  if (subject === 'english') {
    // Parts of speech
    if (lowerQuestion.includes('parts of speech') || lowerQuestion.includes('noun') || lowerQuestion.includes('verb') || lowerQuestion.includes('adjective')) {
      return {
        steps: [
          {
            number: 1,
            title: "The 8 parts of speech",
            content: "English has 8 main parts of speech that categorize how words function.",
            example: "Each word in a sentence has a specific job or function"
          },
          {
            number: 2,
            title: "Nouns",
            content: "Nouns name people, places, things, or ideas.",
            example: "dog, school, happiness, John, Paris"
          },
          {
            number: 3,
            title: "Verbs",
            content: "Verbs show action or state of being.",
            example: "run, think, is, was, have, will be"
          },
          {
            number: 4,
            title: "Adjectives",
            content: "Adjectives describe or modify nouns.",
            example: "big dog, red car, happy child"
          },
          {
            number: 5,
            title: "Other parts of speech",
            content: "Adverbs (modify verbs), pronouns (replace nouns), prepositions (show relationships), conjunctions (connect words), interjections (express emotion).",
            example: "quickly (adverb), he (pronoun), under (preposition), and (conjunction), wow! (interjection)"
          }
        ],
        keyPoints: [
          "Every word in English belongs to one of the 8 parts of speech",
          "The same word can be different parts of speech in different sentences",
          "Understanding parts of speech helps with grammar and writing",
          "Practice identifying parts of speech in sentences you read"
        ]
      };
    }

    // Existing solutions...
    if (lowerQuestion.includes('active') && lowerQuestion.includes('passive')) {
      return {
        steps: [
          {
            number: 1,
            title: "Define active voice",
            content: "In active voice, the subject performs the action.",
            example: "The cat chased the mouse. (Subject 'cat' does the action 'chased')"
          },
          {
            number: 2,
            title: "Define passive voice",
            content: "In passive voice, the subject receives the action.",
            example: "The mouse was chased by the cat. (Subject 'mouse' receives the action)"
          },
          {
            number: 3,
            title: "Identify the structure",
            content: "Active: Subject + Verb + Object. Passive: Subject + be verb + past participle + by + agent",
            formula: "Active: [Subject] [Verb] [Object]\nPassive: [Subject] [be + past participle] [by + agent]"
          },
          {
            number: 4,
            title: "When to use each",
            content: "Use active voice for clarity and directness. Use passive voice when the action is more important than who did it.",
            example: "Active: 'I made a mistake.' Passive: 'Mistakes were made.'"
          }
        ],
        keyPoints: [
          "Active voice is usually clearer and more direct",
          "Passive voice can be useful when the doer is unknown or unimportant",
          "Good writing uses mostly active voice",
          "Both have their place in effective communication"
        ]
      };
    }
    
    if (lowerQuestion.includes('thesis statement')) {
      return {
        steps: [
          {
            number: 1,
            title: "Understand what a thesis statement is",
            content: "A thesis statement is a sentence that clearly states your main argument or position.",
            example: "It's like a roadmap for your entire essay"
          },
          {
            number: 2,
            title: "Make it specific and arguable",
            content: "Your thesis should take a clear position that others could disagree with.",
            example: "Weak: 'Pollution is bad.' Strong: 'Government regulations are the most effective way to reduce industrial pollution.'"
          },
          {
            number: 3,
            title: "Place it strategically",
            content: "Usually place your thesis statement at the end of your introduction paragraph.",
            example: "This gives readers a clear preview of your argument"
          },
          {
            number: 4,
            title: "Make it support your evidence",
            content: "Ensure your thesis can be supported by the evidence you plan to present.",
            example: "If you can't find evidence for your claim, revise your thesis"
          }
        ],
        keyPoints: [
          "A thesis statement should be one clear, concise sentence",
          "It should be arguable, not just a statement of fact",
          "Every paragraph in your essay should support your thesis",
          "Revise your thesis as your argument develops"
        ]
      };
    }
  }
  
  // History Solutions
  if (subject === 'history') {
    // American Revolution
    if (lowerQuestion.includes('american revolution') || lowerQuestion.includes('revolutionary war')) {
      return {
        steps: [
          {
            number: 1,
            title: "Background tensions",
            content: "Growing tensions between Britain and the American colonies over taxes and representation.",
            example: "\"No taxation without representation\" became a rallying cry"
          },
          {
            number: 2,
            title: "Key events leading to war",
            content: "Boston Tea Party (1773), Intolerable Acts (1774), and other conflicts escalated tensions.",
            example: "Colonists dumped British tea into Boston Harbor to protest tea taxes"
          },
          {
            number: 3,
            title: "The war begins",
            content: "Fighting started at Lexington and Concord in 1775.",
            example: "\"The shot heard 'round the world\" marked the beginning of armed conflict"
          },
          {
            number: 4,
            title: "Declaration of Independence",
            content: "In 1776, the colonies formally declared independence from Britain.",
            example: "Written primarily by Thomas Jefferson, it explained why the colonies were breaking away"
          },
          {
            number: 5,
            title: "Victory and consequences",
            content: "The war ended in 1783 with American victory and the Treaty of Paris.",
            example: "Britain recognized American independence and established new borders"
          }
        ],
        keyPoints: [
          "The war lasted from 1775 to 1783",
          "France provided crucial support to the Americans",
          "The victory established the United States as an independent nation",
          "It inspired other democratic movements around the world"
        ]
      };
    }

    // Existing solutions...
    if (lowerQuestion.includes('world war i') || lowerQuestion.includes('wwi')) {
      return {
        steps: [
          {
            number: 1,
            title: "Long-term causes",
            content: "Several factors built tension in Europe before the war began.",
            example: "Imperialism, nationalism, militarism, and alliance systems"
          },
          {
            number: 2,
            title: "The alliance system",
            content: "Europe was divided into two opposing alliance systems.",
            example: "Triple Alliance (Germany, Austria-Hungary, Italy) vs Triple Entente (France, Russia, Britain)"
          },
          {
            number: 3,
            title: "The immediate trigger",
            content: "The assassination of Archduke Franz Ferdinand of Austria-Hungary in Sarajevo.",
            example: "June 28, 1914 - Shot by a Serbian nationalist named Gavrilo Princip"
          },
          {
            number: 4,
            title: "The domino effect",
            content: "The alliance system turned a regional conflict into a world war.",
            example: "Austria-Hungary declared war on Serbia, Russia mobilized, Germany declared war on Russia, etc."
          }
        ],
        keyPoints: [
          "No single cause led to WWI - it was a combination of factors",
          "The alliance system meant that a small conflict could escalate quickly",
          "Nationalism and imperialism created tensions between nations",
          "The war lasted from 1914 to 1918 and changed the world forever"
        ]
      };
    }
  }

  // Geography Solutions
  if (subject === 'geography') {
    // Climate and weather
    if (lowerQuestion.includes('climate') || lowerQuestion.includes('weather')) {
      return {
        steps: [
          {
            number: 1,
            title: "Weather vs Climate",
            content: "Weather is day-to-day conditions; climate is long-term average weather patterns.",
            example: "Today's weather might be rainy, but the climate here is generally dry"
          },
          {
            number: 2,
            title: "Factors affecting climate",
            content: "Latitude, altitude, distance from water, and ocean currents all influence climate.",
            example: "Places near the equator are warmer; mountains are cooler at higher elevations"
          },
          {
            number: 3,
            title: "Climate zones",
            content: "Earth has different climate zones: tropical, temperate, polar, and arid.",
            example: "Tropical zones are hot year-round; polar zones are cold year-round"
          },
          {
            number: 4,
            title: "Human impact",
            content: "Human activities can affect local and global climate patterns.",
            example: "Cities create heat islands; greenhouse gases affect global temperatures"
          }
        ],
        keyPoints: [
          "Climate is measured over 30+ years of weather data",
          "Latitude is the most important factor determining climate",
          "Water bodies moderate temperature (cooler summers, warmer winters)",
          "Climate affects what plants and animals can live in an area"
        ]
      };
    }
  }

  // Economics Solutions
  if (subject === 'economics') {
    // Basic economic concepts
    if (lowerQuestion.includes('supply and demand') || lowerQuestion.includes('market')) {
      return {
        steps: [
          {
            number: 1,
            title: "Understanding demand",
            content: "Demand is how much of a product consumers want to buy at different prices.",
            example: "When prices are low, people usually want to buy more"
          },
          {
            number: 2,
            title: "Understanding supply",
            content: "Supply is how much of a product producers are willing to make at different prices.",
            example: "When prices are high, producers usually want to make more"
          },
          {
            number: 3,
            title: "Market equilibrium",
            content: "The price where supply equals demand is called equilibrium.",
            example: "This is where the supply and demand curves intersect on a graph"
          },
          {
            number: 4,
            title: "Price changes",
            content: "When supply or demand changes, prices adjust to find a new equilibrium.",
            example: "If demand increases but supply stays the same, prices usually go up"
          }
        ],
        keyPoints: [
          "Supply and demand determine prices in a free market",
          "High demand + low supply = higher prices",
          "Low demand + high supply = lower prices",
          "Many factors can shift supply and demand curves"
        ]
      };
    }
  }
  
  // Default response for any subject
  return {
    steps: [
      {
        number: 1,
        title: "Understand the question",
        content: "Read the question carefully and identify what type of problem or concept this involves.",
        example: question
      },
      {
        number: 2,
        title: "Identify key information",
        content: "List all the given information and what you need to find or explain."
      },
      {
        number: 3,
        title: "Choose the right approach",
        content: "Select the appropriate method, formula, or framework for this type of question."
      },
      {
        number: 4,
        title: "Work through systematically",
        content: "Apply your chosen approach step by step, showing all work clearly."
      },
      {
        number: 5,
        title: "Review and verify",
        content: "Check your answer to make sure it makes sense and addresses the question fully."
      }
    ],
    keyPoints: [
      "Always read questions carefully before starting",
      "Break complex problems into smaller, manageable steps",
      "Show all your work clearly and organize your thoughts",
      "Practice similar problems to build understanding and confidence"
    ]
  };
};