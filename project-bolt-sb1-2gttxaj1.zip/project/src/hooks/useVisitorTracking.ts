import { useState, useEffect } from 'react';

interface VisitorStats {
  totalVisitors: number;
  currentVisitors: number;
}

export const useVisitorTracking = () => {
  const [stats, setStats] = useState<VisitorStats>({
    totalVisitors: 0,
    currentVisitors: 1
  });

  useEffect(() => {
    // Get or create visitor ID
    let visitorId = localStorage.getItem('visitor-id');
    if (!visitorId) {
      visitorId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('visitor-id', visitorId);
    }

    // Track this visit
    const visitKey = `visit-${new Date().toDateString()}`;
    const todayVisits = JSON.parse(localStorage.getItem('daily-visits') || '{}');
    
    if (!todayVisits[visitKey]) {
      todayVisits[visitKey] = [];
    }
    
    if (!todayVisits[visitKey].includes(visitorId)) {
      todayVisits[visitKey].push(visitorId);
      localStorage.setItem('daily-visits', JSON.stringify(todayVisits));
    }

    // Calculate total unique visitors across all days
    const allVisitors = new Set();
    Object.values(todayVisits).forEach((visitors: any) => {
      visitors.forEach((id: string) => allVisitors.add(id));
    });

    // Simulate current visitors (in a real app, this would come from a backend)
    const currentVisitors = Math.floor(Math.random() * 8) + 1;

    setStats({
      totalVisitors: allVisitors.size,
      currentVisitors
    });

    // Update current visitors periodically
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        currentVisitors: Math.max(1, Math.floor(Math.random() * 12) + 1)
      }));
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return stats;
};