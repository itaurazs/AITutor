import React from 'react';
import { Users, Eye } from 'lucide-react';
import { useVisitorTracking } from '../hooks/useVisitorTracking';

export const VisitorCounter: React.FC = () => {
  const { totalVisitors, currentVisitors } = useVisitorTracking();

  return (
    <div className="flex items-center space-x-4 text-sm">
      <div className="flex items-center space-x-1 bg-green-50 text-green-700 px-3 py-1 rounded-full">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <Eye className="h-3 w-3" />
        <span className="font-medium">{currentVisitors}</span>
        <span className="hidden sm:inline">online</span>
      </div>
      <div className="flex items-center space-x-1 bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
        <Users className="h-3 w-3" />
        <span className="font-medium">{totalVisitors}</span>
        <span className="hidden sm:inline">visitors</span>
      </div>
    </div>
  );
};