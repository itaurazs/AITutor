import { Subject } from '../types/Subject';

export const subjects: Subject[] = [
  {
    id: 'mathematics',
    name: 'Mathematics',
    icon: 'Calculator',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    description: 'Algebra, Geometry, Calculus, Statistics and more',
    sampleQuestions: [
      "What is the 8 times table?",
      "Solve for x: 2x + 5 = 17",
      "Find the area of a circle with radius 7cm",
      "Add 25 + 37",
      "Subtract 84 - 29",
      "What is 3/4 + 1/8?",
      "Factor: x² - 5x + 6"
    ]
  },
  {
    id: 'science',
    name: 'Science',
    icon: 'Atom',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    description: 'Physics, Chemistry, Biology concepts and problems',
    sampleQuestions: [
      "Explain photosynthesis and its chemical equation",
      "What are the states of matter?",
      "How does the periodic table work?",
      "Calculate the force needed to accelerate a 10kg object at 5m/s²",
      "What happens during mitosis?",
      "Balance this equation: H₂ + O₂ → H₂O"
    ]
  },
  {
    id: 'english',
    name: 'English & Grammar',
    icon: 'BookOpen',
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    description: 'Grammar, Literature, Writing, and Language Arts',
    sampleQuestions: [
      "What are the 8 parts of speech?",
      "What is the difference between active and passive voice?",
      "How do I write a strong thesis statement?",
      "Explain the difference between metaphor and simile",
      "What are the different types of sentences?",
      "How do I properly cite sources in MLA format?"
    ]
  },
  {
    id: 'history',
    name: 'History',
    icon: 'Scroll',
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    description: 'World History, American History, and Social Studies',
    sampleQuestions: [
      "What were the causes of World War I?",
      "Explain the American Revolution",
      "What led to the American Civil War?",
      "Describe the impact of the Industrial Revolution",
      "What was the Cold War about?",
      "Explain the French Revolution and its consequences"
    ]
  },
  {
    id: 'geography',
    name: 'Geography',
    icon: 'Globe',
    color: 'text-teal-600',
    bgColor: 'bg-teal-50',
    description: 'Physical Geography, Human Geography, and Earth Sciences',
    sampleQuestions: [
      "Explain how mountains are formed",
      "What is the difference between weather and climate?",
      "Describe the water cycle",
      "What is plate tectonics?",
      "How do rivers shape the landscape?",
      "Explain population distribution patterns"
    ]
  },
  {
    id: 'economics',
    name: 'Economics',
    icon: 'TrendingUp',
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    description: 'Basic Economics, Supply & Demand, Market Systems',
    sampleQuestions: [
      "What is supply and demand?",
      "Explain inflation and its causes",
      "What is the difference between capitalism and socialism?",
      "How do interest rates affect the economy?",
      "What is GDP and how is it calculated?",
      "Explain opportunity cost with an example"
    ]
  }
];